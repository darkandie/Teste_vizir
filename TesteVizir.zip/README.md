**TECNOLOGIAS E LIBS**

- **REACT JS**
- **CSS**
- **REACT ROUTER**

**LAYOUT**

- **FIGMA**

  Você pode acessar parte do layout através deste <a href="https://www.figma.com/file/uSyqr3i6T3VPVrj7lTomuS/Untitled?node-id=34%3A16" target="__blank">Link</a>.

**PROJETO**

O projeto refere-se a criação de uma página para web da empresa **TELZIR**, para o lançamento do seu novo plano de dados chamado **FALE MAIS**.

**NOTAS ADICIONAIS**

- O projeto é a apenas a página referente ao novo produto.
- Projeto autoral.



**Desenvolvido por Carlos Oliveira** 

Espero que gostem.

