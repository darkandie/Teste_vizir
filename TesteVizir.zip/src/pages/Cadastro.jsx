
import React from 'react';

import NavBar from '../components/NavBar';
import Login from '../components/Login'

const Cadastro = () => {
    return (
    <>
       <NavBar />
       <Login />
    </>
    )
}

export default Cadastro;